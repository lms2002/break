package com.example.breakApp.member.dto

data class RefreshTokenRequest(
    val refreshToken: String
)