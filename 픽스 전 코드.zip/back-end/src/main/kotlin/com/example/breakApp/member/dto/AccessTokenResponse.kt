package com.example.breakApp.member.dto

data class AccessTokenResponse(
    val accessToken: String
)